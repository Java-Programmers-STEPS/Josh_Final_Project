package connection;
import java.sql.*;
public class  ConnDao
{
	     
		 public Statement getcon()
	       {
                Statement stmt=null;
			   try
			   {
				   
			   
				   Class.forName("com.mysql.jdbc.Driver");
					Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ams", "root", "");
    	   stmt=cn.createStatement();
		}
			   catch (Exception e)
			   {
				   System.out.println("======>"+e);
			   }
			   return stmt;
	}
}