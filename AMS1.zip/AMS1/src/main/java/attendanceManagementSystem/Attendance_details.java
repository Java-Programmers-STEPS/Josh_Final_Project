package attendanceManagementSystem;
import java.sql.Blob;
import java.sql.Date;
public class Attendance_details {



	private int id;
	private String studentname,address,gender,subject;
private int studentid;
private Date dateofbirth;
private Blob studentimage;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getStudentname() {
	return studentname;
}
public void setStudentname(String studentname) {
	this.studentname = studentname;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public int getStudentid() {
	return studentid;
}
public void setStudentid(int studentid) {
	this.studentid = studentid;
}
public Date getDateofbirth() {
	return dateofbirth;
}
public void setDateofbirth(Date dateofbirth) {
	this.dateofbirth = dateofbirth;
}
public Blob getStudentimage() {
	return studentimage;
}
public void setStudentimage(Blob studentimage) {
	this.studentimage = studentimage;
}
}

