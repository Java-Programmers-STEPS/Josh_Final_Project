package attendanceManagementSystem;

public class Mark {

}
