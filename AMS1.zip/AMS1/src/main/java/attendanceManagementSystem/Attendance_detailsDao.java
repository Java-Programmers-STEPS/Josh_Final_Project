package attendanceManagementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import attendanceManagementSystem.Attendance_details;

public class Attendance_detailsDao {

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ams", "root", "");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static int register(Attendance_details u) {
		int i = 0;

		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();

		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();

		i = (Integer) session.save(u);

		t.commit();
		session.close();

		return i;

	}

	
	public static List<Attendance_details> getAllRecords() {
		List<Attendance_details> list = new ArrayList<Attendance_details>();

		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from student_details");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Attendance_details stu = new Attendance_details();
				stu.setId(rs.getInt("id"));
				stu.setStudentname(rs.getString("studentname"));
				stu.setAddress(rs.getString("address"));
				stu.setGender(rs.getString("gender"));
				stu.setSubject(rs.getString("subject"));
				stu.setDateofbirth(rs.getDate("dateofbirth"));				
				stu.setStudentimage(rs.getBlob("studentimage"));
				
				list.add(stu);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static Attendance_details getRecordById(int id) {
		Attendance_details u = null;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from student_details where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				u = new Attendance_details();
				u.setId(rs.getInt("id"));
				u.setStudentname(rs.getString("studentname"));
				u.setAddress(rs.getString("address"));
				u.setGender(rs.getString("gender"));
				u.setSubject(rs.getString("subject"));
				u.setDateofbirth(rs.getDate("dateofbirth"));				
				u.setStudentimage(rs.getBlob("studentimage"));
				

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return u;
	}

}
	
	
	
	
	
	

