package attendanceManagementSystem;

public class MarkDao {

}
