package attendanceManagementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;  
   
public class SignupDao { 
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ams", "root", "");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    
public static int register(Signup u){    
 int i=0;    
  
 StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
 Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
  
SessionFactory factory = meta.getSessionFactoryBuilder().build();  
Session session = factory.openSession();  
Transaction t = session.beginTransaction();   
  
i=(Integer)session.save(u);    
  
t.commit();    
session.close();    
    
return i;    
   
 }   

public static List<Signup> getAllRecords() {
	List<Signup> list = new ArrayList<Signup>();

	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select * from u400");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Signup sign = new Signup();
			sign.setId(rs.getInt("id"));
			sign.setFullname(rs.getString("fullname"));
			sign.setEmail(rs.getString("email"));
			sign.setPassword(rs.getString("password"));
			sign.setCpassword(rs.getString("cpassword"));
		
			list.add(sign);
		}
	} catch (Exception e) {
		System.out.println(e);
	}
	return list;
}

public static Signup getRecordById(int id) {
	Signup u = null;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select * from u400 where id=?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			u.setId(rs.getInt("id"));
			u.setFullname(rs.getString("fullname"));
			u.setEmail(rs.getString("email"));
			u.setPassword(rs.getString("password"));
			u.setCpassword(rs.getString("cpassword"));
			

		}
	} catch (Exception e) {
		System.out.println(e);
	}
	return u;
}




}    